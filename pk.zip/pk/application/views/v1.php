<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="<?php echo base_url(); ?>external/style.css">
<script type="text/javascript" src="<?php echo base_url(); ?>external/j.js" >
</script>
</head>
<body>
<form type='post' action='<?php echo base_url(); ?>/index.php/Ctrl_test/get'>
<input type="text" name="name" >
<input type="submit" value="ok">
</form>
<h1> this is view </h1>
</body>
</html>
