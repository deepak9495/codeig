<?php
class Ctrl_test extends CI_Controller
		{
		public function __construct()
				{
				parent::__construct();
				$this->load->helper('url');
				}
		
		
		
		public function index()
			{
		     $this->load->view('v1');
		     
			}
			public function get()
				{
				$name=$_REQUEST['name'];
				echo "$name";
				}
		







			
	/*	public function pks($a=0,$b=0,$i=0)
			{
		switch ($i)
			{
			case 0:
				echo $a+$b;
				break;
			case 1:
				echo $a-$b;
				break;
			case 2:
				echo $a*$b;
				break;
			case 3:
				echo $a/$b;
				break;
				}
				}*/
				
			
		
		}
		




?>
